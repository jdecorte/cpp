// Exercise 12.17 Solution: Building.h
// Calculate the carbon footprint of a building.
#ifndef BUILDING_H
#define BUILDING_H

#include <iostream>
#include "CarbonFootprint.h"

class Building : public CarbonFootprint
{
public:
   Building( int sf )
      : squareFeet( sf )
   {

   } // end Building constructor


   virtual double getCarbonFootprint()
   {
      return squareFeet * ( 1000);
   } // end function getCarbonFootprint
private:
   int squareFeet; // square footage of building
}; // end class Building

#endif

