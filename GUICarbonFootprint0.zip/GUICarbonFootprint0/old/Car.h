// Exercise 12.17 Solution: Car.h
// Calculate the carbon footprint of a car.
#ifndef CAR_H
#define CAR_H

#include <iostream>
#include "CarbonFootprint.h"

class Car : public CarbonFootprint
{
public:
   Car( double g ) : gallons( g )
   {

   } // end Car constructor


   virtual double getCarbonFootprint()
   {
      return gallons * 20;

   } // end function getCarbonFootprint

private:
   double gallons;
}; // end class Car

#endif

