// Exercise 12.17 Solution: Bicycle.h
// Calculate the carbon footprint of a bicycle.
#ifndef BICYCLE_H
#define BICYCLE_H

#include <iostream>
#include "CarbonFootprint.h"

class Bicycle : public CarbonFootprint
{
public:
   virtual double getCarbonFootprint()
   {
      return 0;
   } // end function getCarbonFootprint
}; // end class Bicycle

#endif

