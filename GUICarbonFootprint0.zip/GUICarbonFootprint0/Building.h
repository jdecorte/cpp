// Exercise 12.17 Solution: Building.h
// Calculate the carbon footprint of a building.
#ifndef BUILDING_H
#define BUILDING_H

#include <iostream>
#include "CarbonFootprint.h"

class Building : public CarbonFootprint
{
public:
   Building( int sm ):CarbonFootprint("Building"), squareMeter( sm )
   {
      carbonFootprint = squareMeter * 100;
   }

   ~Building()
   {
        printDtorMsg();
   }
private:
   int squareMeter; // square footage of building
}; // end class Building

#endif

