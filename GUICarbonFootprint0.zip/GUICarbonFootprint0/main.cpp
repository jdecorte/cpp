#include <stdexcept>
#include <fstream>

#include <QApplication>
#include <QMessageBox>

#include "mainwindow.h"

using namespace std;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    CarbonDialog w;
    w.show();

    QFont sansFont("Helvetica [Cronyx]", 16);
    QApplication::setFont(sansFont);

    return a.exec();
}
