// Calculate the carbon footprint of a car.
#ifndef CAR_H
#define CAR_H

#include <iostream>
#include "CarbonFootprint.h"
#include <typeinfo>

class Car : public CarbonFootprint
{
public:
   Car( double l ): CarbonFootprint("Car")
   {
       if (l < 0 || l > 100)
       {
           throw(std::logic_error("Doorgegeven liters ongeldig"));
       }
       liter = l;
       carbonFootprint = liter * 20;
   }
   ~Car()
   {
        printDtorMsg();
   }

private:
   double liter;
}; // end class Car

#endif
