#include <fstream>
#include <QtWidgets>
#include <QComboBox>
#include <QMenuBar>

#include "CarbonFootprint.h"
#include "Bicycle.h"
#include "Car.h"
#include "Building.h"

#include "mainwindow.h"

using namespace std;

CarbonDialog::CarbonDialog(QWidget *parent) : QDialog(parent)
{
    comboBox = new QComboBox();
    comboBox->addItem("Bicycle");
    comboBox->addItem("Car");
    comboBox->addItem("Building");

    vBoxLayout = new QVBoxLayout;
    vBoxLayout->addWidget(comboBox);

    okButton = new QPushButton("Ok");
    vBoxLayout->addWidget(okButton);

    setLayout(vBoxLayout);
    setWindowTitle(tr("Carbon footprint"));
    setFixedWidth(400);
    setFixedHeight(200);
    connect(comboBox, SIGNAL(currentTextChanged(const QString &)), this, SLOT(comboChanged()));
    connect(okButton, SIGNAL(clicked()), this, SLOT(okClicked()));
}

CarbonDialog::~CarbonDialog()
{
    delete comboBox;
    delete okButton;
    delete lineEdit;
    delete vBoxLayout;
}

void CarbonDialog::comboChanged()
{
    // Cleanup variable stuff
    delete propertyLabel;
    propertyLabel = nullptr;
    delete lineEdit;
    lineEdit = nullptr;

    QString text = comboBox->currentText();

    if (text == "Bicycle")
    {
        okClicked();
        return;
    }
    lineEdit = new QLineEdit;

    if (text == "Car")
    {
        propertyLabel = new QLabel("&Liter/100 km:");
    }
    else if (text == "Building")
    {
        propertyLabel = new QLabel("&Surface:");
    }

    delete hBoxLayout;
    propertyLabel->setBuddy(lineEdit);
    hBoxLayout = new QHBoxLayout();
    hBoxLayout->addWidget(propertyLabel);
    hBoxLayout->addWidget(lineEdit);

    delete vBoxLayout;
    vBoxLayout = new QVBoxLayout;
    vBoxLayout->addWidget(comboBox);
    vBoxLayout->addLayout(hBoxLayout);
    vBoxLayout->addWidget(okButton);

    setLayout(vBoxLayout);
}

void CarbonDialog::okClicked()
{
    QString choice = comboBox->currentText();

    CarbonFootprintPtr cbftp = nullptr;

    try
    {
        if (choice == "Bicycle")
        {
            cbftp = make_shared<Bicycle>();
        }
        else if (choice == "Car")
        {
            float liters = lineEdit->text().toFloat();
            if (liters <= 0)
                throw logic_error("Only positive values allowed");
            else
                cbftp = make_shared<Car>(liters);
        }
        else
        {
            float sqmeters = lineEdit->text().toFloat();
            if (sqmeters <= 0)
                throw logic_error("Only positive values allowed");
            else
                cbftp = make_shared<Building>(sqmeters);
        }

        double CO2 = cbftp->getCarbonFootprint();

        QMessageBox msgBox;
        msgBox.setText(QString("Carbon footprint = " + QString::number(CO2)));
        msgBox.exec();
    }
    catch (exception& e)
    {
        QMessageBox msgBox;
        msgBox.setText(e.what());
        msgBox.exec();
    }          
}


