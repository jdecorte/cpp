#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QDialog>
#include <QLineEdit>
#include <QVBoxLayout>
#include <QLabel>

class QComboBox;
class QPushButton;


class CarbonDialog : public QDialog
{
    Q_OBJECT
public:
    explicit CarbonDialog(QWidget *parent = nullptr);
    ~CarbonDialog();

private slots:
    void comboChanged();
    void okClicked();

private:
    QComboBox* comboBox = nullptr;
    QPushButton* okButton = nullptr;
    QLineEdit* lineEdit = nullptr;
    QVBoxLayout* vBoxLayout = nullptr;
    QHBoxLayout* hBoxLayout = nullptr;
    QLabel* propertyLabel = nullptr;
};

#endif // MAINWINDOW_H
