// CarbonFootprint.h
// base class for classes that can calculate carbon footprint.
#ifndef CARBONFOOTPRINT_H
#define CARBONFOOTPRINT_H

#include <string>
#include <list>
#include <memory>
#include <iostream>

class CarbonFootprint;  // forward declaration

using CarbonFootprintPtr = std::shared_ptr<CarbonFootprint>;
using CarbonFootprintLst = std::list<CarbonFootprintPtr>;

class CarbonFootprint
{
public:
    CarbonFootprint(std::string n):name(n) {};

    virtual ~CarbonFootprint() {};
    double getCarbonFootprint() const {return carbonFootprint;}
    std::string getName() const {return name;}

protected:
    void printDtorMsg()
    {
//      std::cout << "dtor of " << typeid(*this).name() << " called" << std::endl;
    }
    std::string name;
    double carbonFootprint;
};


#endif
