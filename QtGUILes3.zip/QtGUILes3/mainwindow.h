#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <string>

#include <QMainWindow>
#include <QDialog>

class QCheckBox;
class QLabel;
class QLineEdit;
class QPushButton;
class FindDialog;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(std::string keuze, QWidget *parent = nullptr);
    ~MainWindow() {};
    void virtual closeEvent(QCloseEvent *event) override;

private slots:
    void Find();

private:
    FindDialog* findDialog = nullptr;
    std::string keuze = "";
};

class FindDialog : public QDialog
{
    Q_OBJECT
public:
    explicit FindDialog(std::string keuze, QWidget *parent = nullptr);
    ~FindDialog();
    void findNext(const QString& str, Qt::CaseSensitivity cs);
    void findPrevious(const QString& str, Qt::CaseSensitivity cs);

private slots:
    void findClicked();
    void enableFindButton(const QString& text);

private:
    QLabel *label;
    QLineEdit *lineEdit;
    QCheckBox *caseCheckBox;
    QCheckBox *backwardCheckBox;
    QPushButton *findButton;
    QPushButton *closeButton;
};

#endif // MAINWINDOW_H
