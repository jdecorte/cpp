#include <stdexcept>

#include "mainwindow.h"

#include <QtWidgets>

using namespace std;

MainWindow::MainWindow(string kz, QWidget *parent) : QMainWindow(parent),keuze(kz)
{
    QMenu* editMenu = menuBar()->addMenu(tr("&Edit"));

    QAction* find = new QAction(tr("&Find"),this);
    editMenu->addAction(find);
    connect(find,SIGNAL(triggered()),this,SLOT(Find()));

    std::string windowTitle = std::string("Qt GUI Les 2 - Build: ") + __DATE__ + " " + __TIME__;
    setWindowTitle(windowTitle.c_str());

    setMinimumSize(160, 160);
    resize(480, 320);
}

void MainWindow::Find()
{
    delete findDialog;
    findDialog = new FindDialog(keuze);
    findDialog->show();
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    QMessageBox::StandardButton closeBtn = QMessageBox::Yes;

    closeBtn = QMessageBox::question( this, "Quit",
                                    tr("Are your sure you want to quit?\n"),
                                    QMessageBox::No | QMessageBox::Yes,
                                    QMessageBox::Yes);

    if (closeBtn == QMessageBox::Yes)
    {
        event->accept();
    }
    else
        event->ignore();
}

FindDialog::FindDialog(std::string keuze, QWidget *parent) : QDialog(parent)
{
    try
    {
        if (keuze == "text")
            label = new QLabel("&Find text:");
        else if (keuze == "number")
            label = new QLabel("&Find number:");
        else
            throw invalid_argument("Invalid parameter: only text/number allowed");

        lineEdit = new QLineEdit;
        label->setBuddy(lineEdit);
        caseCheckBox = new QCheckBox("Match case");
        backwardCheckBox = new QCheckBox("Search backward");
        findButton = new QPushButton("Find");


        findButton->setDefault(true);
        findButton->setEnabled(false);

        closeButton = new QPushButton("Close");

        connect(lineEdit,SIGNAL(textChanged(const QString&)),this,
                SLOT(enableFindButton(const QString&)));

        connect(findButton,SIGNAL(clicked()),this, SLOT(findClicked()));

        connect(closeButton,SIGNAL(clicked()),this, SLOT(close()));

        QHBoxLayout *topLeftLayout = new QHBoxLayout;
        topLeftLayout->addWidget(label);
        topLeftLayout->addWidget(lineEdit);

        QVBoxLayout *leftLayout = new QVBoxLayout;
        leftLayout->addLayout(topLeftLayout);
        leftLayout->addWidget(caseCheckBox);
        leftLayout->addWidget(backwardCheckBox);

        QVBoxLayout *rightLayout = new QVBoxLayout;
        rightLayout->addWidget(findButton);
        rightLayout->addWidget(closeButton);
        rightLayout->addStretch();

        QHBoxLayout *mainLayout = new QHBoxLayout;
        mainLayout->addLayout(leftLayout);
        mainLayout->addLayout(rightLayout);

        setLayout(mainLayout);


        std::string windowTitle = std::string("Qt GUI Les 2 - Build: ") + __DATE__ + " " + __TIME__;
        setWindowTitle(windowTitle.c_str());

    //    setFixedHeight(sizeHint().height());

        setFixedHeight(200);
        setFixedWidth(300);
    }
    catch (exception& e)
    {
        QMessageBox msgBox;
        msgBox.setText(QString(e.what()));
        msgBox.exec();
        exit(EXIT_FAILURE);
    }
}

FindDialog::~FindDialog()
{
}


void FindDialog::enableFindButton(const QString& text)
{
    findButton->setEnabled(!text.isEmpty());
}

void FindDialog::findClicked()
{
    QString text = lineEdit->text();
    Qt::CaseSensitivity cs =
            caseCheckBox->isChecked() ? Qt::CaseSensitive : Qt::CaseInsensitive;

    if (backwardCheckBox->isChecked())
    {
        findPrevious(text,cs);
    }
    else
    {
        findNext(text,cs);
    }
}

void FindDialog::findNext(const QString& str, Qt::CaseSensitivity cs)
{
    QMessageBox msgBox;
    if (cs == Qt::CaseSensitive)
        msgBox.setText(QString("Next " + str + " is searched case sensitive"));
    else
        msgBox.setText(QString("Next " + str + " is searched case insensitive"));

    msgBox.exec();
}

void FindDialog::findPrevious(const QString& str, Qt::CaseSensitivity cs)
{
    QMessageBox msgBox;
    if (cs == Qt::CaseSensitive)
        msgBox.setText(QString("Previous " + str + " is searched case sensitive"));
    else
        msgBox.setText(QString("Previous " + str + " is searched case insensitive"));

    msgBox.exec();
}
