#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <string>

#include <QDialog>

class QCheckBox;
class QLabel;
class QLineEdit;
class QPushButton;

/*
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE
*/

class MainWindow : public QDialog
{
    Q_OBJECT

public:
    MainWindow(std::string keuze, QWidget *parent = nullptr);
    ~MainWindow();
    void findNext(const QString& str, Qt::CaseSensitivity cs);
    void findPrevious(const QString& str, Qt::CaseSensitivity cs);

private slots:
    void findClicked();
    void enableFindButton(const QString& text);

private:
    QLabel *label;
    QLineEdit *lineEdit;
    QCheckBox *caseCheckBox;
    QCheckBox *backwardCheckBox;
    QPushButton *findButton;
    QPushButton *closeButton;
    // Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
