#include <string>
#include <stdexcept>
#include "mainwindow.h"

#include <QApplication>


using namespace std;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    string keuze = string(argv[1]);
    MainWindow w(keuze);
    w.show();
    return a.exec();
}
