// Exercise 12.17 Solution: Bicycle.h
// Calculate the carbon footprint of a bicycle.
#ifndef BICYCLE_H
#define BICYCLE_H

#include <iostream>
#include "CarbonFootprint.h"

class Bicycle : public CarbonFootprint
{
public:

    Bicycle() : CarbonFootprint("Bicycle")
    {
        carbonFootprint = 0;
    }
}; // end class Bicycle

#endif


