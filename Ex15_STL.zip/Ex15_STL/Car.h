// Exercise 12.17 Solution: Car.h
// Calculate the carbon footprint of a car.
#ifndef CAR_H
#define CAR_H

#include <iostream>
#include "CarbonFootprint.h"

class Car : public CarbonFootprint
{
public:
   Car( double l ): CarbonFootprint("Car"), liter( l )
   {
      carbonFootprint = liter * 20;
   }

private:
   double liter;
}; // end class Car

#endif
