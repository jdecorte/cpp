// Exercise 15 STL
// Test program for CarbonFootprint and implementing classes.
#include <list>
#include <fstream>
#include <cstdlib>
#include "CarbonFootprint.h"
#include "Bicycle.h"
#include "Building.h"
#include "Car.h"
using namespace std;

void print(const list<CarbonFootprint>& lst)
{
    for ( auto const& item: lst)
       cout << item.getName() << ": " << item.getCarbonFootprint() << endl;
}

bool comp(const CarbonFootprint& c1, const CarbonFootprint& c2)
{
    return c1.getCarbonFootprint() < c2.getCarbonFootprint();
}

int main()
{
   list< CarbonFootprint> lst;

   // add elements to list
   lst.push_back( Bicycle() );
   lst.push_back(  Building( 250 ) );
   lst.push_back(  Car( 8 ) );

   cout << "BEFORE SORTING:" << endl;
   print(lst);

   lst.sort();

   cout << "AFTER SORTING:" << endl;
   print(lst);

   lst.reverse();

   cout << "AFTER REVERSE:" << endl;
   print(lst);

   lst.sort(comp);

   cout << "AFTER SORTING WITH COMP FUNCTION:" << endl;
   print(lst);

   lst.reverse();

   cout << "File output..." << endl;

   ofstream ofile("footprints.txt",ios::out);
   if (!ofile)
   {
       cerr << "File could not be opened" << endl;
       exit(EXIT_FAILURE);
   }

   for ( auto const & item: lst)
      ofile << item.getName() << ": " << item.getCarbonFootprint() << endl;

   ofile.close();

} // end main

