// Exercise 12.17 Solution: CarbonFootprint.h
// Abstract base class for classes that can calculate carbon footprint.
#ifndef CARBONFOOTPRINT_H
#define CARBONFOOTPRINT_H

#include <string>

class CarbonFootprint
{
public:
    CarbonFootprint(std::string n):name(n) {};

    ~CarbonFootprint() {}; // end class CarbonFootprint
    double getCarbonFootprint() const {return carbonFootprint;}
    std::string getName() const {return name;}

    bool operator<(const CarbonFootprint& cfp)
    {
        if (carbonFootprint < cfp.getCarbonFootprint())
            return true;
        else
            return false;
    }
protected:
    std::string name;
    double carbonFootprint;
};

#endif
