// Exercise 12.17 Solution: Car.h
// Calculate the carbon footprint of a car.
#ifndef CAR_H
#define CAR_H

#include <iostream>
#include "CarbonFootprint.h"
#include <typeinfo>

class Car : public CarbonFootprint
{
public:
   Car( double l ): CarbonFootprint("Car")
   {
      if (l < 0 || l > 100)
      {
          throw(std::logic_error("Doorgegeven liters ongeldig"));
      }
      liter = l;
      carbonFootprint = liter * 20;
      printCtorMsg();
   }
   ~Car()
   {
        printDtorMsg();
   }

private:
   double liter;
}; // end class Car

#endif
