// Exercise 15 STL
// Test program for CarbonFootprint and implementing classes.
#include <list>
#include <fstream>
#include <cstdlib>
#include "CarbonFootprint.h"
#include <memory>
#include "Bicycle.h"
#include "Building.h"
#include "Car.h"
using namespace std;

void print(const CarbonFootprintLst& lst)
{
    for ( auto const& item: lst)
       cout << item->getName() << ": " << item->getCarbonFootprint() << endl;
}

bool comp(const CarbonFootprintPtr c1, const CarbonFootprintPtr c2)
{
    return c1->getCarbonFootprint() < c2->getCarbonFootprint();
}

int main()
{
   try
   {
       CarbonFootprintLst lst;

       // add elements to list
       lst.push_back( make_shared<Bicycle>());
       lst.push_back( make_shared<Building>( 250 ));
       lst.push_back( make_shared<Car>( 5 )) ;

       cout << "BEFORE SORTING:" << endl;
       print(lst);

       lst.sort();  // sort with overloaded operator<

       cout << "AFTER SORTING:" << endl;
       print(lst);

       lst.reverse();
       cout << "AFTER REVERSE:" << endl;
       print(lst);

       lst.sort(comp);

       cout << "AFTER SORTING WITH COMP FUNCTION:" << endl;
       print(lst);

       lst.reverse();
       cout << "AFTER REVERSE:" << endl;
       print(lst);


       lst.sort([](const CarbonFootprintPtr& c1, const CarbonFootprintPtr& c2)
            {return c1->getCarbonFootprint() < c2->getCarbonFootprint();});
       cout << "AFTER SORTING WITH LAMBDA EXPRESSION:" << endl;
       print(lst);


       cout << "File output..." << endl;

       ofstream ofile("footprints.txt",ios::out);
       if (!ofile)
       {
           cerr << "File could not be opened" << endl;
           exit(EXIT_FAILURE);
       }

       for ( auto const & item: lst)
          ofile << item->getName() << ": " << item->getCarbonFootprint() << endl;

       ofile.close();
    }
    catch (logic_error& e)
    {
        cout << "Exception: " << e.what() << endl;
    }
    catch (exception& e)
    {
        cout << "Exception: " << e.what() << endl;
    }
    catch (...)
    {
        cout << "Unhandled exception occured" << endl;
    }

} // end main

