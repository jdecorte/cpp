// Exercise 12.17 Solution: CarbonFootprint.h
// Abstract base class for classes that can calculate carbon footprint.
#ifndef CARBONFOOTPRINT_H
#define CARBONFOOTPRINT_H

#include <string>
#include <list>
#include <memory>
#include <iostream>
#include <stdexcept>

class CarbonFootprint;  // forward declaration

using CarbonFootprintPtr = std::shared_ptr<CarbonFootprint>;
using CarbonFootprintLst = std::list<CarbonFootprintPtr>;

class CarbonFootprint
{
public:
    CarbonFootprint(std::string n):name(n) {};

    virtual ~CarbonFootprint() {};
    double getCarbonFootprint() const {return carbonFootprint;}
    std::string getName() const {return name;}

protected:
    void printCtorMsg()
    {
      std::cout << "ctor of " << typeid(*this).name() << " called" << std::endl;
    }
    void printDtorMsg()
    {
      std::cout << "dtor of " << typeid(*this).name() << " called" << std::endl;
    }
    std::string name;
    double carbonFootprint;
};


bool operator<(const CarbonFootprintPtr& cfp1, const CarbonFootprintPtr& cfp2)
{
    if (cfp1->getCarbonFootprint() < cfp2->getCarbonFootprint())
        return true;
    else
        return false;
}


#endif
